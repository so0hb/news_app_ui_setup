package com.example.news_app_ui_setup

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
